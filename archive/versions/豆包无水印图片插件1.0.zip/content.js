// Capture right-click on target images and send URL to background
(function init() {
	// const log = (...args) => console.log("[ImageLinkCatcher][content]", ...args);
	let lastClipboardCaptureAt = 0;
	let hasCapturedClipboardImage = false;
	let lastMenuCopyAt = 0;
	let currentSessionId = 0;
	let lastContextSnapshot = { url: null, sessionId: 0 };
	let mergeInProgress = false;
	let mergeUnlockTimer = null;

	function newSession() {
		currentSessionId = Date.now();
		return currentSessionId;
	}

	function lockMerge() {
		mergeInProgress = true;
		if (mergeUnlockTimer) clearTimeout(mergeUnlockTimer);
		mergeUnlockTimer = setTimeout(() => { mergeInProgress = false; }, 15000);
	}
	function unlockMerge() {
		mergeInProgress = false;
		if (mergeUnlockTimer) { clearTimeout(mergeUnlockTimer); mergeUnlockTimer = null; }
	}

	function markClipboardCaptured() {
		lastClipboardCaptureAt = Date.now();
		hasCapturedClipboardImage = true;
	}
	function shouldSkipClipboardCapture() {
		const now = Date.now();
		return hasCapturedClipboardImage && (now - lastClipboardCaptureAt) < 2000; // 2s window
	}

	function getImageSrcFromEvent(event) {
		const target = event.target;
		if (!target) return null;
		// Match the in-painting picture image or any IMG under cursor
		const img = target.tagName === "IMG" ? target : target.closest && target.closest("img");
		if (!img) return null;
		// Only accept when it matches expected attribute or has src
		if (img.getAttribute("data-testid") === "in_painting_picture" || img.src) {
			return img.currentSrc || img.src || null;
		}
		return null;
	}

	function decodeHtmlEntities(str) {
		if (!str) return str;
		const div = document.createElement("div");
		div.innerHTML = str;
		return div.textContent || div.innerText || "";
	}

	function extractPrefixedFromString(input) {
		if (!input) return [];
		const s = decodeHtmlEntities(String(input));
		// Broaden charset to include common URL chars; stop at whitespace
		const regex = /@https:\/\/p3-flow-imagex-sign\.byteimg\.com[\w\-./~%?=&:#,]+/g;
		const out = [];
		let m;
		while ((m = regex.exec(s)) !== null) {
			out.push(m[0]);
		}
		// Log for debugging
		if (out.length) {
			// log("prefixed matches", out.map(x => x.length));
		}
		return out;
	}

	function extractImgSrcsFromHtml(html) {
		if (!html) return [];
		const container = document.createElement("div");
		container.innerHTML = html;
		const imgs = Array.from(container.querySelectorAll("img"));
		return imgs.map(img => img.currentSrc || img.src).filter(Boolean);
	}

	function sendMessage(message) {
		chrome.runtime.sendMessage(message);
	}

	function sendSrc(src) {
		if (!src) return;
		lastContextSnapshot = { url: src, sessionId: currentSessionId };
		sendMessage({ type: "contextmenu-image-src", src, sessionId: currentSessionId });
	}

	async function tryReadClipboardImages(tag) {
		try {
			if (shouldSkipClipboardCapture()) return null;
			if (!navigator.clipboard || typeof navigator.clipboard.read !== "function") return null;
			const items = await navigator.clipboard.read();
			for (const item of items) {
				const type = item.types && item.types.find(t => t.startsWith("image/"));
				if (!type) continue;
				const blob = await item.getType(type);
				if (!blob || !blob.size) continue;
				const dataUrl = await new Promise((resolve, reject) => {
					const reader = new FileReader();
					reader.onload = () => resolve(String(reader.result || ""));
					reader.onerror = reject;
					reader.readAsDataURL(blob);
				});
				// log("clipboard image captured", { tag, type, size: blob.size, preview: dataUrl.slice(0, 60) });
				markClipboardCaptured();
				sendMessage({ type: "copied-payload", payload: { text: "", html: "", imgSrcs: [], prefixed: [], imageDataUrl: dataUrl, sessionId: currentSessionId } });
				return dataUrl;
			}
			return null;
		} catch (e) {
			return null;
		}
	}

	// Use capture to beat page handlers that might stopPropagation/preventDefault
	window.addEventListener(
		"contextmenu",
		(event) => {
			try {
				newSession();
				const src = getImageSrcFromEvent(event);
				if (src) {
					// log("contextmenu detected img, session", currentSessionId);
					sendSrc(src);
				}
			} catch (e) {}
		},
		true
	);

	// copy event (kept for completeness)
	window.addEventListener(
		"copy",
		async (event) => {
			try {
				hasCapturedClipboardImage = false; // reset for new copy gesture
				const dt = event.clipboardData;
				let text = "";
				let html = "";
				if (dt) {
					try { text = dt.getData("text/plain") || ""; } catch (_) {}
					try { html = dt.getData("text/html") || ""; } catch (_) {}
				}
				const imgSrcs = extractImgSrcsFromHtml(html);
				const prefixed = [
					...extractPrefixedFromString(text),
					...extractPrefixedFromString(html)
				];
				// log("copy event", { sessionId: currentSessionId, textLen: text.length, htmlLen: html.length, imgSrcsCount: imgSrcs.length, prefixedCount: prefixed.length });
				sendMessage({ type: "copied-payload", payload: { text, html, imgSrcs, prefixed, sessionId: currentSessionId } });
				await tryReadClipboardImages("copy");
			} catch (e) {}
		},
		true
	);

	// Monkey-patch clipboard writes (keep session id)
	(function patchClipboard() {
		const nav = window.navigator;
		if (!nav || !nav.clipboard) return;
		try {
			const originalWriteText = nav.clipboard.writeText ? nav.clipboard.writeText.bind(nav.clipboard) : null;
			if (originalWriteText) {
				nav.clipboard.writeText = async function patchedWriteText(text) {
					try {
						const prefixed = extractPrefixedFromString(text);
						// log("clipboard.writeText intercepted", { sessionId: currentSessionId, textPreview: typeof text === "string" ? String(text).slice(0, 200) : String(text), prefixedCount: prefixed.length });
						sendMessage({ type: "copied-payload", payload: { text: String(text || ""), html: "", imgSrcs: [], prefixed, sessionId: currentSessionId } });
						await tryReadClipboardImages("writeText");
					} catch (_) {}
					return originalWriteText(text);
				};
			}
			const originalWrite = nav.clipboard.write ? nav.clipboard.write.bind(nav.clipboard) : null;
			if (originalWrite) {
				nav.clipboard.write = async function patchedWrite(items) {
					try {
						let text = "";
						let html = "";
						let imgSrcs = [];
						if (Array.isArray(items)) {
							for (const it of items) {
								if (!it || typeof it.getType !== "function") continue;
								try {
									if (it.types && it.types.includes("text/html")) {
										const b = await it.getType("text/html");
										html = await b.text();
										imgSrcs = extractImgSrcsFromHtml(html);
									}
								} catch (_) {}
								try {
									if (it.types && it.types.includes("text/plain")) {
										const b = await it.getType("text/plain");
										text = await b.text();
									}
								} catch (_) {}
							}
						}
						const prefixed = [
							...extractPrefixedFromString(text),
							...extractPrefixedFromString(html)
						];
						// log("clipboard.write intercepted", { sessionId: currentSessionId, textLen: text.length, htmlLen: html.length, imgSrcsCount: imgSrcs.length, prefixedCount: prefixed.length });
						sendMessage({ type: "copied-payload", payload: { text, html, imgSrcs, prefixed, sessionId: currentSessionId } });
						await tryReadClipboardImages("write");
					} catch (_) {}
					return originalWrite(items);
				};
			}
			const originalExec = document.execCommand ? document.execCommand.bind(document) : null;
			if (originalExec) {
				document.execCommand = function patchedExecCommand(cmd, showUI, value) {
					const result = originalExec(cmd, showUI, value);
					if (String(cmd).toLowerCase() === "copy") {
						// log("execCommand('copy') intercepted", { sessionId: currentSessionId });
						try {
							setTimeout(async () => {
								try {
									const text = await navigator.clipboard.readText();
									const prefixed = extractPrefixedFromString(text);
									sendMessage({ type: "copied-payload", payload: { text, html: "", imgSrcs: [], prefixed, sessionId: currentSessionId } });
									await tryReadClipboardImages("execCommand");
								} catch (_) {}
							}, 120);
						} catch (_) {}
					}
					return result;
				};
			}
		} catch (e) {}
	})();

	async function loadImage(src) {
		return new Promise((resolve, reject) => {
			const img = new Image();
			img.crossOrigin = "anonymous";
			img.onload = () => resolve(img);
			img.onerror = reject;
			img.src = src;
		});
	}

	async function mergeAndDownload(interceptedUrl, contextUrl) {
		try {
			if (mergeInProgress) {
				// log("merge skipped: in progress"); 
				return; 
			}
			if (!interceptedUrl || !contextUrl) return;
			lockMerge();
			const [imgTop, imgBottom] = await Promise.all([
				loadImage(interceptedUrl),
				loadImage(contextUrl)
			]);
			const w = imgTop.naturalWidth;
			const h = imgTop.naturalHeight;
			if (w !== imgBottom.naturalWidth || h !== imgBottom.naturalHeight) { unlockMerge(); return; }
			const half = Math.floor(h / 2);
			const canvas = document.createElement("canvas");
			canvas.width = w;
			canvas.height = h;
			const c = canvas.getContext("2d");
			c.drawImage(imgTop, 0, 0, w, half, 0, 0, w, half);
			c.drawImage(imgBottom, 0, half, w, h - half, 0, half, w, h - half);
			const out = canvas.toDataURL("image/png");
			sendMessage({ type: "download-merged", dataUrl: out, sessionId: currentSessionId });
			// log("auto merged and requested background download", { sessionId: currentSessionId });
		} catch (e) {
			// log("merge error", e);
			unlockMerge();
		}
	}

	chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
		if (!msg) return;
		if (msg.type === "merge-and-download") {
			const { ctxUrl, itcUrl } = msg;
			if (ctxUrl && itcUrl) { mergeAndDownload(itcUrl, ctxUrl); return; }
			chrome.storage.local.get(["contextMenuImageUrls", "interceptedImageUrls"]).then(({ contextMenuImageUrls, interceptedImageUrls }) => {
				if (contextMenuImageUrls && interceptedImageUrls) { mergeAndDownload(interceptedImageUrls, contextMenuImageUrls); }
			});
			return;
		}
		if (msg.type === "download-ack") {
			unlockMerge();
		}
	});

	// Bind to site custom copy menu item: click -> wait -> read clipboard image (session-guarded) -> merge
	window.addEventListener("click", async (e) => {
		try {
			const target = e.target;
			const menuItem = target && (target.closest && target.closest('[data-testid="right_click_copy_image"]'));
			if (!menuItem) return;
			const now = Date.now();
			if (now - lastMenuCopyAt < 1500) return; // throttle
			lastMenuCopyAt = now;
			const sessionAtClick = currentSessionId || newSession();
			setTimeout(async () => {
				try {
					const interceptedDataUrl = await tryReadClipboardImages("menu-copy");
					if (!interceptedDataUrl) return;
					// Use snapshot instead of storage to avoid races
					if (!lastContextSnapshot.url || lastContextSnapshot.sessionId !== sessionAtClick) {
						// log("skip merge due to snapshot/session mismatch", { snapshot: lastContextSnapshot, sessionAtClick });
						return;
					}
					await mergeAndDownload(interceptedDataUrl, lastContextSnapshot.url);
				} catch (_) {}
			}, 600);
		} catch (_) {}
	}, true);

	const observer = new MutationObserver(() => {});
	observer.observe(document.documentElement, { childList: true, subtree: true });

	// log("content script initialized");
})();
