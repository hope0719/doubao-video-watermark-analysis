// Keys used across extension
const STORAGE_KEYS = {
  downloadEnabled: "downloadEnabled"
};

function $(id) { return document.getElementById(id); }

async function getSetting(key, defaultValue) {
  try {
    const obj = await chrome.storage.local.get([key]);
    if (Object.prototype.hasOwnProperty.call(obj, key)) return obj[key];
    return defaultValue;
  } catch (_) {
    return defaultValue;
  }
}

async function setSetting(key, value) {
  try {
    await chrome.storage.local.set({ [key]: value });
  } catch (_) {}
}

document.addEventListener("DOMContentLoaded", async () => {
  const toggle = $("toggle-download");
  const enabled = await getSetting(STORAGE_KEYS.downloadEnabled, true);
  toggle.checked = Boolean(enabled);
  toggle.addEventListener("change", async () => {
    await setSetting(STORAGE_KEYS.downloadEnabled, toggle.checked);
  });
});


