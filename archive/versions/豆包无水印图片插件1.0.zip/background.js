// Minimal logging helper
// const log = (...args) => console.log("[ImageLinkCatcher]", ...args);

// Storage keys
const STORAGE_KEYS = {
	contextMenuImageUrls: "contextMenuImageUrls",
	interceptedImageUrls: "interceptedImageUrls",
	contextSessionId: "contextSessionId",
	interceptedSessionId: "interceptedSessionId",
	currentSessionId: "currentSessionId",
    downloadEnabled: "downloadEnabled"
};

let lastDownloadedSessionId = null;

async function saveSingleValue(key, value) {
	if (typeof value !== "string" && typeof value !== "number") return;
	try {
		await chrome.storage.local.set({ [key]: value });
		// log("Saved", key, String(value).slice(0, 120));
	} catch (e) {
		// log("Storage error", e);
	}
}

async function clearStoredImages() {
	try {
		await chrome.storage.local.remove([
			STORAGE_KEYS.contextMenuImageUrls,
			STORAGE_KEYS.interceptedImageUrls,
			STORAGE_KEYS.contextSessionId,
			STORAGE_KEYS.interceptedSessionId
		]);
		// log("Cleared stored images");
	} catch (e) {
		// log("Clear storage error", e);
	}
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
	try {
		// log("onMessage", { type: message && message.type, fromTab: sender && sender.tab && sender.tab.id });
		if (!message) return;
		if (message.type === "clear-storage") {
			clearStoredImages();
			return;
		}
		if (message.type === "download-merged" && typeof message.dataUrl === "string") {
			const { sessionId } = message;
			// Always ack to unlock content-side merge lock
			if (sender && sender.tab && sender.tab.id) {
				chrome.tabs.sendMessage(sender.tab.id, { type: "download-ack" });
			}
            // Respect user setting: downloadEnabled (default true)
            chrome.storage.local.get([STORAGE_KEYS.downloadEnabled]).then(({ downloadEnabled }) => {
				const enabled = typeof downloadEnabled === "boolean" ? downloadEnabled : true;
				if (!enabled) {
					return; // Skip downloading when disabled
				}
				if (sessionId && lastDownloadedSessionId === sessionId) {
					// log("skip duplicate download for session", sessionId);
					return;
				}
				const baseName = `img${Date.now()}.png`;
                chrome.downloads.download({ url: message.dataUrl, filename: baseName, saveAs: true }, () => {
					if (chrome.runtime.lastError) {
						// log("downloads error", chrome.runtime.lastError.message);
						return;
					}
					lastDownloadedSessionId = sessionId || Date.now();
					// log("downloads started for merged image", { sessionId: lastDownloadedSessionId, filename });
					clearStoredImages();
				});
			});
			return;
		}
		if (message.type === "contextmenu-image-src" && typeof message.src === "string") {
			const { sessionId } = message;
			saveSingleValue(STORAGE_KEYS.contextMenuImageUrls, message.src);
			if (typeof sessionId === "number") {
				saveSingleValue(STORAGE_KEYS.contextSessionId, sessionId);
				saveSingleValue(STORAGE_KEYS.currentSessionId, sessionId);
			}
			return;
		}
		if (message.type === "copied-payload" && message.payload) {
			const { imageDataUrl, sessionId } = message.payload || {};
			if (typeof imageDataUrl === "string" && imageDataUrl.startsWith("data:image")) {
				saveSingleValue(STORAGE_KEYS.interceptedImageUrls, imageDataUrl);
				if (typeof sessionId === "number") {
					saveSingleValue(STORAGE_KEYS.interceptedSessionId, sessionId);
				}
			}
			return;
		}
	} catch (e) {
		// log("onMessage error", e);
	}
});

// log("Background service worker initialized");
